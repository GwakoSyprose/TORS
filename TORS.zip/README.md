# TORS
Traffic Offenders Registration System
The Traffic Offenders Registration System is a demerit system for drivers who gain demerit points for traffic offences, which may result in suspension or loss of a driving license. 
This system tracks offences committed by a driver and issue points on these offences and when the offences point surpasses a certain number their driving licenses gets suspended automatically. Three suspension will result it being revoked
