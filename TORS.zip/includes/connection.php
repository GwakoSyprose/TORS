<?php
   $link= mysqli_connect("localhost", "root","","tobs");

    if(mysqli_connect_error()){
            
            die("Database Connection Error");
        }
    
?>
